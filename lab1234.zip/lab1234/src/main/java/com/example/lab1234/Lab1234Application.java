package com.example.lab1234;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab1234Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab1234Application.class, args);
	}

}
