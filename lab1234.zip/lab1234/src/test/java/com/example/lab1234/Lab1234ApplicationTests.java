package com.example.lab1234;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1234ApplicationTests {

	@Test
	void contextLoads() {
	}

}
